</div>
</div>
</div>
</div>
<!-- content @e -->
<!-- footer @s -->
<div class="nk-footer">
    <div class="container-fluid">
        <div class="nk-footer-wrap">
            <div class="nk-footer-copyright"> &copy; 2023. Designed & Developed by <a href="https://weblytechnolab.com" target="_blank">Webly Technolab</a>
            </div>
        </div>
    </div>
</div>
<!-- footer @e -->
</div>
<!-- wrap @e -->
</div>
<!-- main @e -->
</div>
<!-- app-root @e -->
<!-- JavaScript -->
<?php require('modals.php');?>
<script src="./assets/js/bundle.js?ver=3.1.3"></script>
<script src="./assets/js/scripts.js?ver=3.1.3"></script>
<link rel="stylesheet" href="./assets/css/editors/quill.css?ver=3.1.3">
<script src="./assets/js/libs/editors/quill.js?ver=3.1.3"></script>
<script src="./assets/js/editors.js?ver=3.1.3"></script>
<script src="./assets/js/charts/chart-lms.js?ver=3.1.3"></script>
</body>

</html>